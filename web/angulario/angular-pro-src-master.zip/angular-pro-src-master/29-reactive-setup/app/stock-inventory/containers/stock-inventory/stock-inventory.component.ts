import { Component } from '@angular/core';

@Component({
  selector: 'stock-inventory',
  styleUrls: ['stock-inventory.component.scss'],
  template: `
    <div class="stock-inventory">
      Hello world!
    </div>
  `
})
export class StockInventoryComponent {
  
}