export interface Product {
  id: number,
  price: number,
  name: string
}