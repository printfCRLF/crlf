let pizza = {
  name: 'Pepperoni',
  price: 25,
};

if (true) {
  let pizza = 25;
}

// const pizza: any = {
//   name: 'Pepperoni',
//   price: 25,
// };

// pizza.toppings = ['pepperoni'];
