const toppings = ['bacon', 'chilli'];

const newToppings = ['pepperoni'];

const allToppings = [...newToppings, ...toppings];

console.log(allToppings);
