let coupon: any;

coupon = 25;

coupon = 'pizza25';

coupon = true;
