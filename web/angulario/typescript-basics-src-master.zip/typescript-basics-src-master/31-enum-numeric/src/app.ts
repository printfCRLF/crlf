enum Sizes {
  Small,
  Medium,
  Large,
}
enum Sizes {
  ExtraLarge = 3,
}

const selectedSize = 2;

console.log(Sizes.Large, Sizes[selectedSize]);
