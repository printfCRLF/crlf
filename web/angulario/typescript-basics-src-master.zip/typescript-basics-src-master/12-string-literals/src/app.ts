const toppings = ['bacon', 'pepperoni'];

const order = `You have ordered a pizza with ${toppings.length} toppings!`;
