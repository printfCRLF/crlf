console.log('Ahoy TypeScript!');
