let pizza: [string, number, boolean];

pizza = ['Pepperoni', 20, true];
