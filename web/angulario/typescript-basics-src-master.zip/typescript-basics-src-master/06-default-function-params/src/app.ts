function multiply(a, b = 25) {
  return a * b;
}

console.log(multiply(5));
console.log(multiply(5, 35));
