import { uppercase } from './utils';

const pizza = 'Pepperoni';

console.log(uppercase(pizza));
