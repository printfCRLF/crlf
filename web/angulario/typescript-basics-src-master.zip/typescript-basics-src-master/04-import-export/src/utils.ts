export function uppercase(str) {
  return str.toUpperCase();
}
