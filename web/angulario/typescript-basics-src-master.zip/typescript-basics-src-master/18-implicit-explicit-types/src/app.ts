let implicitCoupon = 'pizza25';
let explicitCoupon: string;

explicitCoupon = 'pizza25';
