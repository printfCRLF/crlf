let sizes: number[];

sizes = [1, 2, 3];

let toppings: Array<string>;

toppings = ['pepperoni', 'tomato', 'bacon'];
