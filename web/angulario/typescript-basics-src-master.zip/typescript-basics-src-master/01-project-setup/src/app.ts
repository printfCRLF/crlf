console.log('Hey TypeScript!');
